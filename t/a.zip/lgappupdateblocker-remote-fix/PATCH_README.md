# LG App Update Blocker — webOS Remote Navigation Fix

This is a **UI-only patch overlay** for `dr0dr1dr2dr3/lgappupdateblocker` 1.0.0.

## Problem
The upstream app exposes ordinary HTML buttons and mouse hover styling but does not implement 5-way TV-remote focus/navigation. On TVs/remotes without Magic Remote pointer control, arrow and OK navigation can therefore appear completely dead.

## What this patch changes
- Adds explicit D-pad spatial navigation for Left/Right/Up/Down.
- Makes OK/Enter activate the focused button.
- Adds an obvious focus ring so you can see what the remote is selecting.
- Scrolls focused controls into view.
- Watches for controls becoming enabled after the root service is elevated.
- Does **not** alter the root service, update-domain list, hosts-file behavior, persistent script, SSH handling, or blocked-app logic.

## Apply to upstream source
Copy the two files in `frontend/` into the upstream `frontend/` directory, then add these two lines to `frontend/index.html`:

Inside `<head>` after the existing `<style>...</style>` block:

```html
<link rel="stylesheet" href="remote-focus.css">
```

Immediately after the existing `<script src="index.js"></script>` line:

```html
<script src="remote-navigation.js"></script>
```

Then update `webpack.config.js` CopyPlugin frontend pattern so all three frontend static files are copied instead of only `index.html`:

```js
{ context: 'frontend', from: '*.html' },
{ context: 'frontend', from: '*.css' },
{ context: 'frontend', from: 'remote-navigation.js' },
```

The upstream webpack config currently copies only `frontend/index.html`, so without this adjustment the two patch files will not land in `dist/`.

## Build
From the upstream project root:

```sh
npm install
npm run build
npm run package
```

This patch was intentionally kept separate from service code to minimize risk in a root-level utility.
